$loot spawn ~ ~ ~ loot $(loot_table)

